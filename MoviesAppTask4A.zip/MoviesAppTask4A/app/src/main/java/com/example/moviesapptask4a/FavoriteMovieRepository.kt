package com.example.moviesapptask4a

import androidx.lifecycle.LiveData
import com.example.moviesapptask4a.model.FavoriteMovie

class FavoriteMovieRepository(private val favoriteMovieDao: FavoriteMovieDao) {
    fun getAllFavoriteMovies(): LiveData<List<FavoriteMovie>> {
        return favoriteMovieDao.getAllFavoriteMovies()
    }

    fun isMovieFavorite(movieId: Int): LiveData<Boolean> {
        return favoriteMovieDao.isMovieFavorite(movieId)
    }

    fun insertMovie(movie: FavoriteMovie) {
        favoriteMovieDao.insertMovie(movie)
    }

    suspend fun deleteMovie(movie: FavoriteMovie) {
        //favoriteMovieDao.deleteMovie(movie)
    }

}