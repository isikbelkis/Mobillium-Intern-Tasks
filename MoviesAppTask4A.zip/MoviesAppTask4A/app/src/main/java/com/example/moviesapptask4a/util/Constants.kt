package com.example.moviesapptask4a.util

object Constants {
    const val BASE_URL = "https://api.themoviedb.org/3/movie/"
    const val BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500"
    const val BEARER_TOKEN =
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJiYWQ1YzE5ZGYwYjY3MWUxNDUwOTRiMzRlYzRhZjY4NCIsIm5iZiI6MTcyMzQ3MzIxNi4wMTQ1NTcsInN1YiI6IjY2YjI1MmIzMDMyMjIyNTE2MDcwMGFjMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.7BMohSKWZGWZsebIYZp-p9HyG3R_4W6c-_OjlS4Z0Qo"
}