package com.example.moviesapptask4a.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.moviesapptask4a.FavoriteMovieRepository
import com.example.moviesapptask4a.FavoriteRoomDatabase
import com.example.moviesapptask4a.model.FavoriteMovie
import com.example.moviesapptask4a.model.MoviesItem
import kotlinx.coroutines.launch

class FavoriteMovieViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FavoriteMovieRepository
    val favoriteMovies: LiveData<List<FavoriteMovie>>
    init {
        val favoriteDao = FavoriteRoomDatabase.getDatabase(application).favoriteMovieDao()
        repository = FavoriteMovieRepository(favoriteDao)
        favoriteMovies = repository.getAllFavoriteMovies()
    }

    fun toggleFavorite(movie: MoviesItem) {
        viewModelScope.launch {
            val favoriteMovie = FavoriteMovie(movie.id!!, movie.title!!, movie.posterPath!!)

            val isFavorite = repository.isMovieFavorite(movie.id).value ?: false

            if (isFavorite) {
                repository.deleteMovie(favoriteMovie)
            } else {
                repository.insertMovie(favoriteMovie)
            }
        }
    }

    fun isFavorite(movieId: Int): LiveData<Boolean> {
        return repository.isMovieFavorite(movieId)
    }
}